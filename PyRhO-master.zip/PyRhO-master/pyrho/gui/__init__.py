from pkg_resources import resource_filename

# resource_filename(package_or_requirement, resource_name)
