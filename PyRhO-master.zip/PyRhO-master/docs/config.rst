Package: ``config`` API
=======================

.. automodule:: pyrho.config
    :members:
